﻿# SendChart

The goal to send the created chart by mail.

The first obstacle was that the graph tied to the WPF environment.

The `MainViewModel` could be replaced with references. The `DayWeathers` and `VisualTime` need to be changed. The source is changed to use it a 'general use'.



